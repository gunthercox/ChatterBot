# -*- coding: utf-8 -*-
injectable = "injectable"
nested_injector = "nested_injector"
this = "this"
lazy_import = "lazy_import"
