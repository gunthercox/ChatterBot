# -*- coding: utf-8 -*-
class DependencyError(Exception):
    """Broken dependencies configuration error."""

    pass
